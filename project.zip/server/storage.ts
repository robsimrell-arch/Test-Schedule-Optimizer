import { db } from "./db";
import {
  testEquipment, partNumbers, testSteps, stepEquipment, workOrders, partEquipmentCompatibility,
  type TestEquipment, type InsertTestEquipment,
  type PartNumber, type InsertPartNumber,
  type TestStep, type InsertTestStep,
  type WorkOrder, type InsertWorkOrder,
  type PartNumberWithSteps, type TestStepWithEquipment,
  type InsertStepEquipment, type PartEquipmentCompatibility
} from "@shared/schema";
import { eq, desc, and, notInArray } from "drizzle-orm";

export interface IStorage {
  // Equipment
  getEquipment(): Promise<TestEquipment[]>;
  createEquipment(equipment: InsertTestEquipment): Promise<TestEquipment>;
  updateEquipment(id: number, equipment: Partial<InsertTestEquipment>): Promise<TestEquipment | undefined>;
  deleteEquipment(id: number): Promise<void>;

  // Parts
  getParts(): Promise<PartNumber[]>;
  getPart(id: number): Promise<PartNumberWithSteps | undefined>;
  createPart(part: InsertPartNumber): Promise<PartNumber>;
  updatePart(id: number, part: Partial<InsertPartNumber>): Promise<PartNumber | undefined>;
  deletePart(id: number): Promise<void>;

  // Steps
  createStep(step: InsertTestStep, equipmentRequirements: { equipmentId: number; quantityRequired: number; durationMinutes?: number | null }[]): Promise<TestStepWithEquipment>;
  updateStep(id: number, step: Partial<InsertTestStep>, equipmentRequirements?: { equipmentId: number; quantityRequired: number; durationMinutes?: number | null }[]): Promise<TestStepWithEquipment | undefined>;
  deleteStep(id: number): Promise<void>;
  getStepsByPartId(partId: number): Promise<TestStepWithEquipment[]>;

  // Orders
  getOrders(): Promise<(WorkOrder & { partNumber: PartNumber })[]>;
  createOrder(order: InsertWorkOrder): Promise<WorkOrder>;
  updateOrder(id: number, order: Partial<InsertWorkOrder>): Promise<WorkOrder | undefined>;
  deleteOrder(id: number): Promise<void>;
  
  // Helpers for scheduler
  getAllSteps(): Promise<TestStepWithEquipment[]>;

  // Part-Chamber Compatibility
  getPartCompatibility(partNumberId: number): Promise<PartEquipmentCompatibility[]>;
  setPartCompatibility(partNumberId: number, compatibilities: { equipmentId: number; durationMinutes?: number | null; changeoverMinutes?: number | null }[]): Promise<PartEquipmentCompatibility[]>;
  getAllPartCompatibility(): Promise<PartEquipmentCompatibility[]>;
  
  // Chambers (for Chamber Compatibility tab)
  getChambers(): Promise<TestEquipment[]>;
}

export class DatabaseStorage implements IStorage {
  async getEquipment(): Promise<TestEquipment[]> {
    return await db.select().from(testEquipment);
  }

  async createEquipment(equipment: InsertTestEquipment): Promise<TestEquipment> {
    const [newItem] = await db.insert(testEquipment).values(equipment).returning();
    return newItem;
  }

  async deleteEquipment(id: number): Promise<void> {
    await db.delete(testEquipment).where(eq(testEquipment.id, id));
  }

  async updateEquipment(id: number, equipment: Partial<InsertTestEquipment>): Promise<TestEquipment | undefined> {
    const [updated] = await db.update(testEquipment).set(equipment).where(eq(testEquipment.id, id)).returning();
    return updated;
  }

  async getParts(): Promise<PartNumberWithSteps[]> {
    const parts = await db.query.partNumbers.findMany({
      with: {
        steps: {
          with: {
            equipmentRequirements: {
              with: {
                equipment: true
              }
            }
          },
          orderBy: (steps, { asc }) => [asc(steps.stepOrder)]
        }
      }
    });
    return parts as PartNumberWithSteps[];
  }

  async getPart(id: number): Promise<PartNumberWithSteps | undefined> {
    const part = await db.query.partNumbers.findFirst({
      where: eq(partNumbers.id, id),
      with: {
        steps: {
          with: {
            equipmentRequirements: {
              with: {
                equipment: true
              }
            }
          },
          orderBy: (steps, { asc }) => [asc(steps.stepOrder)]
        }
      }
    });
    return part as PartNumberWithSteps | undefined;
  }

  async createPart(part: InsertPartNumber): Promise<PartNumber> {
    const [newItem] = await db.insert(partNumbers).values(part).returning();
    return newItem;
  }

  async updatePart(id: number, part: Partial<InsertPartNumber>): Promise<PartNumber | undefined> {
    const [updated] = await db.update(partNumbers).set(part).where(eq(partNumbers.id, id)).returning();
    return updated;
  }

  async deletePart(id: number): Promise<void> {
    await db.delete(partNumbers).where(eq(partNumbers.id, id));
  }

  async createStep(step: InsertTestStep, equipmentRequirements: { equipmentId: number; quantityRequired: number; durationMinutes?: number | null }[]): Promise<TestStepWithEquipment> {
    return await db.transaction(async (tx) => {
      const [newStep] = await tx.insert(testSteps).values(step).returning();
      
      if (equipmentRequirements.length > 0) {
        await tx.insert(stepEquipment).values(
          equipmentRequirements.map(eq => ({ 
            stepId: newStep.id, 
            equipmentId: eq.equipmentId,
            quantityRequired: eq.quantityRequired,
            durationMinutes: eq.durationMinutes ?? null
          }))
        );
      }

      const result = await tx.query.testSteps.findFirst({
        where: eq(testSteps.id, newStep.id),
        with: {
          equipmentRequirements: {
            with: {
              equipment: true
            }
          }
        }
      });
      return result as TestStepWithEquipment;
    });
  }

  async updateStep(id: number, step: Partial<InsertTestStep>, equipmentRequirements?: { equipmentId: number; quantityRequired: number; durationMinutes?: number | null }[]): Promise<TestStepWithEquipment | undefined> {
    return await db.transaction(async (tx) => {
      if (Object.keys(step).length > 0) {
        await tx.update(testSteps).set(step).where(eq(testSteps.id, id));
      }
      
      if (equipmentRequirements !== undefined) {
        await tx.delete(stepEquipment).where(eq(stepEquipment.stepId, id));
        if (equipmentRequirements.length > 0) {
          await tx.insert(stepEquipment).values(
            equipmentRequirements.map(eqReq => ({ 
              stepId: id, 
              equipmentId: eqReq.equipmentId,
              quantityRequired: eqReq.quantityRequired,
              durationMinutes: eqReq.durationMinutes ?? null
            }))
          );
        }
      }

      const result = await tx.query.testSteps.findFirst({
        where: eq(testSteps.id, id),
        with: {
          equipmentRequirements: {
            with: {
              equipment: true
            }
          }
        }
      });
      return result as TestStepWithEquipment | undefined;
    });
  }

  async deleteStep(id: number): Promise<void> {
    await db.transaction(async (tx) => {
      await tx.delete(stepEquipment).where(eq(stepEquipment.stepId, id));
      await tx.delete(testSteps).where(eq(testSteps.id, id));
    });
  }

  async getStepsByPartId(partId: number): Promise<TestStepWithEquipment[]> {
    const steps = await db.query.testSteps.findMany({
      where: eq(testSteps.partNumberId, partId),
      with: {
        equipmentRequirements: {
          with: {
            equipment: true
          }
        }
      }
    });
    return steps as TestStepWithEquipment[];
  }

  async getOrders(): Promise<(WorkOrder & { partNumber: PartNumber })[]> {
    const orders = await db.query.workOrders.findMany({
      with: {
        partNumber: true
      },
      orderBy: (orders, { desc }) => [desc(orders.priority), desc(orders.createdAt)]
    });
    return orders as (WorkOrder & { partNumber: PartNumber })[];
  }

  async createOrder(order: InsertWorkOrder): Promise<WorkOrder> {
    const [newItem] = await db.insert(workOrders).values(order).returning();
    return newItem;
  }

  async deleteOrder(id: number): Promise<void> {
    await db.delete(workOrders).where(eq(workOrders.id, id));
  }

  async updateOrder(id: number, order: Partial<InsertWorkOrder>): Promise<WorkOrder | undefined> {
    const [updated] = await db.update(workOrders).set(order).where(eq(workOrders.id, id)).returning();
    return updated;
  }

  async getAllSteps(): Promise<TestStepWithEquipment[]> {
    const steps = await db.query.testSteps.findMany({
      with: {
        equipmentRequirements: {
          with: {
            equipment: true
          }
        }
      }
    });
    return steps as TestStepWithEquipment[];
  }

  async getPartCompatibility(partNumberId: number): Promise<PartEquipmentCompatibility[]> {
    return await db.select().from(partEquipmentCompatibility).where(eq(partEquipmentCompatibility.partNumberId, partNumberId));
  }

  async setPartCompatibility(partNumberId: number, compatibilities: { equipmentId: number; durationMinutes?: number | null; changeoverMinutes?: number | null }[]): Promise<PartEquipmentCompatibility[]> {
    // Deduplicate by equipmentId (keep last occurrence)
    const dedupedMap = new Map<number, { equipmentId: number; durationMinutes: number | null; changeoverMinutes: number | null }>();
    for (const c of compatibilities) {
      dedupedMap.set(c.equipmentId, { 
        equipmentId: c.equipmentId, 
        durationMinutes: c.durationMinutes ?? null,
        changeoverMinutes: c.changeoverMinutes ?? null
      });
    }
    const dedupedCompatibilities = Array.from(dedupedMap.values());
    const equipmentIdsToKeep = dedupedCompatibilities.map(c => c.equipmentId);
    
    return await db.transaction(async (tx) => {
      // Delete only rows that are not in the new set (diff-based approach)
      if (equipmentIdsToKeep.length > 0) {
        await tx.delete(partEquipmentCompatibility)
          .where(and(
            eq(partEquipmentCompatibility.partNumberId, partNumberId),
            notInArray(partEquipmentCompatibility.equipmentId, equipmentIdsToKeep)
          ));
      } else {
        // If no compatibilities to keep, delete all for this part
        await tx.delete(partEquipmentCompatibility)
          .where(eq(partEquipmentCompatibility.partNumberId, partNumberId));
      }
      
      // Upsert new compatibilities (insert or update duration and changeover)
      for (const c of dedupedCompatibilities) {
        await tx.insert(partEquipmentCompatibility)
          .values({ 
            partNumberId, 
            equipmentId: c.equipmentId,
            durationMinutes: c.durationMinutes,
            changeoverMinutes: c.changeoverMinutes
          })
          .onConflictDoUpdate({
            target: [partEquipmentCompatibility.partNumberId, partEquipmentCompatibility.equipmentId],
            set: { 
              durationMinutes: c.durationMinutes,
              changeoverMinutes: c.changeoverMinutes
            }
          });
      }
      
      return await tx.select().from(partEquipmentCompatibility).where(eq(partEquipmentCompatibility.partNumberId, partNumberId));
    });
  }

  async getAllPartCompatibility(): Promise<PartEquipmentCompatibility[]> {
    return await db.select().from(partEquipmentCompatibility);
  }
  
  async getChambers(): Promise<TestEquipment[]> {
    const allEquipment = await db.select().from(testEquipment);
    return allEquipment.filter(eq => eq.name.toLowerCase().includes("chamber"));
  }
}

export const storage = new DatabaseStorage();
